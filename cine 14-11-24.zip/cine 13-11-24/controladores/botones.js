const botones = [
    {nombre: "Inicio", ruta: "/"},
    {nombre: "Registro", ruta: "/registro"},
    {nombre: "Login", ruta: "/login"},
    {nombre: "Contacto", ruta: "/contacto"}
 ]


 export{
    botones
 }