import bcrypt from 'bcryptjs'; // Importa bcrypt
import connection from './db.js';  // Asegúrate de que la conexión a la base de datos esté configurada correctamente

// Función para registrar un nuevo usuario
export const registerUser = (req, res) => {
  console.log('Datos recibidos:', req.body); // Verifica los datos recibidos
  const { email, password, birth_date } = req.body;

  // Validación de los campos
  if (!email || !password || !birth_date) {
    return res.status(400).send('Todos los campos son obligatorios');
  }

  // Verificar si el correo ya está registrado
  const checkEmailQuery = 'SELECT * FROM users WHERE email = ?';
  connection.query(checkEmailQuery, [email], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error al verificar el correo en la base de datos');
    }

    if (results.length > 0) {
      return res.status(400).send('El correo ya está registrado');
    }

    // Encriptar la contraseña
    bcrypt.hash(password, 10, (err, hashedPassword) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error al encriptar la contraseña');
      }

      // Consulta para insertar el nuevo usuario en la base de datos
      const insertQuery = 'INSERT INTO users (email, password, birth_date) VALUES (?, ?, ?)';
      connection.query(insertQuery, [email, hashedPassword, birth_date], (error, results) => {
        if (error) {
          console.error(error);
          return res.status(500).send('Error al registrar el usuario');
        }

        // Respuesta exitosa
        res.status(200).send('Usuario registrado exitosamente');
      });
    });
  });
};
